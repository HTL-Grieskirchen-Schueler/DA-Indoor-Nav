﻿namespace DAServer.Dtos;

public class NodeDto
{
  public int Id { get; set; }
  public double Left { get; set; }
  public double Top { get; set; }
}
